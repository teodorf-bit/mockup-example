# Mockup example


###  Installation
Use installation guide to ensure that all dependencies are installed.

Notice for the mockup example:
- scikit-learn version 0.21.2  
- Django scripy form installed using: $pip install --upgrade django-crispy-forms
