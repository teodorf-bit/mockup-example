from settings import BASE_DIR

#Print base directory of you app
print(BASE_DIR)
