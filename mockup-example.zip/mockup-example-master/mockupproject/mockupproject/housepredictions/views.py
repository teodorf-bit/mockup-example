from django.shortcuts import render, redirect
from django.http import HttpResponse

from .models import HousePrice, Predictions
from .forms import HousePriceForm

import os
from mockupproject.settings import BASE_DIR
import joblib
import pandas as pd

model_file = os.path.join(BASE_DIR,'final_model.sav')
learning_model = joblib.load(model_file)

# Create your views here.
def index(request): #args, kwargs

    # Instantiate an empty form
    form = HousePriceForm()

    # If POST request, process the form data
    if request.method == 'POST':

        #Assign the form instance with data from the request
        form = HousePriceForm(request.POST)

        #Check whether all data is valid and process it
        if form.is_valid():
            # validated form data is in the form.cleaned_data dictionary
            area = form.cleaned_data['area']
            neighbourhood = form.cleaned_data['neighbourhood'] # Neighborhood
            roomsTotal = form.cleaned_data['roomsTotal'] # TotRmsAbvGrd
            yearBuilt = form.cleaned_data['yearBuilt'] # YearBuilt

            # Parse data into feature array for predicition
            new_pred_data = pd.DataFrame({'GrLivArea': area,'Neighborhood':neighbourhood,'TotRmsAbvGrd': roomsTotal,
            'YearBuilt': yearBuilt} , index=[0])

            # Make Predictions
            new_prediction = int(learning_model.predict(new_pred_data))

            # Add  and save the predicted prices to  Predictions DB
            add_prediction_data = Predictions(input_GrLivArea=area, input_Neighborhood=neighbourhood,
            input_TotRmsAbvGrd=roomsTotal, input_yearBuilt=yearBuilt,  predicted_price=new_prediction)

            add_prediction_data.save()

            context ={'predictions': new_prediction}

            # Render the prediction results
            return render(request, 'housepredictions/predictions.html',{'form': form, 'prediction':new_prediction})


    # if it is GET request, just show the form
    else:
        form = HousePriceForm()
        return render(request,'housepredictions/index.html',{'form': form})
