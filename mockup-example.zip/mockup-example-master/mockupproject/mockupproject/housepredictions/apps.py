from django.apps import AppConfig


class HousepredictionsConfig(AppConfig):
    name = 'housepredictions'
