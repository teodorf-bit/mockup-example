from django import forms
from .models import HousePrice

# Declare that this is a ModelForm hence forms.ModelForm
class HousePriceForm(forms.Form):
    area = forms.IntegerField(initial ='Size in square feet', label='Size') # lb_GrLivArea
    neighbourhood = forms.CharField(label='Neighborhood') # lb_Neighborhood
    roomsTotal = forms.IntegerField(label='Total Rooms') # lb_TotRmsAbvGrd
    #garageCarSpace = forms.IntegerField(label='Garage Space') #lb_GarageCars
    yearBuilt = forms.IntegerField(label='Year Built') #lb_YearBuilt
